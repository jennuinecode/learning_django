$(document).ready(function() {
    console.log("jquery loaded!");
});
