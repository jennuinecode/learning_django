from __future__ import unicode_literals

from django.apps import AppConfig


class NinjaColorsConfig(AppConfig):
    name = 'ninja_colors'
