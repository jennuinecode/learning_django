$(document).ready(
    alert("Button clicked!");
)
